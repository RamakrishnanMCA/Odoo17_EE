# -*- coding: utf-8 -*-
{
    'name': "Odoo Fuck",
    'summary': """This module will catch odoo enterprise edition and start fucking it until 6000ac.""",
    'description': """This module will catch odoo enterprise edition and start fucking it until 6000ac.""",
    'author': "AliFaleh",
    'website': "/odoo_fuck/static/description/info.html",
    'category': 'crack',
    'version': '1.0',
    'depends': ['base','web_enterprise'],
    'data': ['sql/odoo_fuck.sql',],
    'qweb': ['static/src/xml/base.xml',],
}
